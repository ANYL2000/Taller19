<?php
require_once '../assets/conexion/servidor.php';
$conexion = connect($host, $port, $db_name, $db_username, $db_password);
$conexion->query("SET NAMES 'utf8'");

date_default_timezone_set('America/Mexico_City');   

$año = date('Y');
$mes = date('m');



if($mes>=1&&$mes<=6){
  $año.="A";
 
  $fecha = "Enero-Junio";
 


}else if($mes>=7&&$mes<=12){
  $año.="B";
 
  $fecha = "Julio-Diciembre";
 
 

}else if($mes>12||$mes<1){

  echo "<script>alert('Configure correctamente su zona horaria');</script>";
  echo "<script>window.location='alumno1.php';</script>";
}

$query =$conexion->prepare("SELECT idTalleres,NombreTallerista,NombreTaller, Calendario, Turno, Tipo,Dia,Lugares_Faltantes
FROM mostrar_talleres WHERE Calendario='$año';");



$query->execute();
$resultado =$query->fetchAll();


?>
<!DOCTYPE html>
<html lang="en">
<head>

<header>
    <title>Talleres</title>
</header>

<link rel="stylesheet" href="../assets/css/estilo_alumno1.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<?php include 'header_alumno.php'; ?>
</head>
<body>
    


<div class="fondo">

<h1 class="titulo_taller">Elige tu taller</h1>

<table class="table-responsive">
    <thead>
<tr class="fila_principal">
    <td>Nombre del taller</td>
    <td>Calendario</td>
    <td>Turno</td>
    <td>Tipo</td>
    <td>Dia</td>
    <td>Lugares Disponibles</td>
</tr>
</thead>
<?php  foreach($resultado as $taller): if($taller['Lugares_Faltantes']>0){ ?>

    <!--taller1.2.php?idtaller='<?php //echo $taller['NombreTaller']?>'-->

<tr class="filas_secundarias" id="color_gris">
    <td> <a href="alumno1.1.php?tallerista=<?php echo $taller['NombreTallerista']?>&taller=<?php echo $taller['NombreTaller']?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"> <?php echo $taller['NombreTaller']?> </a></td>
    <td> <a href="alumno1.1.php?tallerista=<?php echo $taller['NombreTallerista']?>&taller=<?php echo $taller['NombreTaller']?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"> <?php echo $taller['Calendario']?></a></td>
    <td><a href="alumno1.1.php?tallerista=<?php echo $taller['NombreTallerista']?>&taller=<?php echo $taller['NombreTaller']?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Turno']?></a></td>
    <td><a href="alumno1.1.php?tallerista=<?php echo $taller['NombreTallerista']?>&taller=<?php echo $taller['NombreTaller']?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Tipo']?></a></td>
    <td><a href="alumno1.1.php?tallerista=<?php echo $taller['NombreTallerista']?>&taller=<?php echo $taller['NombreTaller']?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Dia']?></a></td>
    <td><a href="alumno1.1.php?tallerista=<?php echo $taller['NombreTallerista']?>&taller=<?php echo $taller['NombreTaller']?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Lugares_Faltantes']?></a></td>
</tr>
</a>

<?php  } endforeach; ?>

</table>

</div>
<script src="../assets/js/jquery-3.6.0.min.js"></script>

</body>
</html>
<?php $conexion = null;?>